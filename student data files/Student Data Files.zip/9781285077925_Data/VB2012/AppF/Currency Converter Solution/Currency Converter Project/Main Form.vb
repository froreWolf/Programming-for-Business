﻿' Name:         Currency Converter Project
' Purpose:      Convert American dollars to
'               British pounds and Mexican pesos
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub
End Class
