<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.radArkansas = New System.Windows.Forms.RadioButton()
        Me.radIllinois = New System.Windows.Forms.RadioButton()
        Me.radOregon = New System.Windows.Forms.RadioButton()
        Me.radKentucky = New System.Windows.Forms.RadioButton()
        Me.radWisconsin = New System.Windows.Forms.RadioButton()
        Me.radLittleRock = New System.Windows.Forms.RadioButton()
        Me.radMadison = New System.Windows.Forms.RadioButton()
        Me.radFrankfort = New System.Windows.Forms.RadioButton()
        Me.radSpringfield = New System.Windows.Forms.RadioButton()
        Me.radSalem = New System.Windows.Forms.RadioButton()
        Me.btnVerify = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblMsg = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'radArkansas
        '
        Me.radArkansas.Checked = True
        Me.radArkansas.Location = New System.Drawing.Point(9, 25)
        Me.radArkansas.Margin = New System.Windows.Forms.Padding(2)
        Me.radArkansas.Name = "radArkansas"
        Me.radArkansas.Size = New System.Drawing.Size(100, 23)
        Me.radArkansas.TabIndex = 0
        Me.radArkansas.TabStop = True
        Me.radArkansas.Text = "&Arkansas"
        '
        'radIllinois
        '
        Me.radIllinois.Location = New System.Drawing.Point(9, 52)
        Me.radIllinois.Margin = New System.Windows.Forms.Padding(2)
        Me.radIllinois.Name = "radIllinois"
        Me.radIllinois.Size = New System.Drawing.Size(100, 23)
        Me.radIllinois.TabIndex = 1
        Me.radIllinois.Text = "&Illinois"
        '
        'radOregon
        '
        Me.radOregon.Location = New System.Drawing.Point(9, 107)
        Me.radOregon.Margin = New System.Windows.Forms.Padding(2)
        Me.radOregon.Name = "radOregon"
        Me.radOregon.Size = New System.Drawing.Size(100, 23)
        Me.radOregon.TabIndex = 3
        Me.radOregon.Text = "&Oregon"
        '
        'radKentucky
        '
        Me.radKentucky.Location = New System.Drawing.Point(9, 79)
        Me.radKentucky.Margin = New System.Windows.Forms.Padding(2)
        Me.radKentucky.Name = "radKentucky"
        Me.radKentucky.Size = New System.Drawing.Size(100, 23)
        Me.radKentucky.TabIndex = 2
        Me.radKentucky.Text = "&Kentucky"
        '
        'radWisconsin
        '
        Me.radWisconsin.Location = New System.Drawing.Point(9, 134)
        Me.radWisconsin.Margin = New System.Windows.Forms.Padding(2)
        Me.radWisconsin.Name = "radWisconsin"
        Me.radWisconsin.Size = New System.Drawing.Size(100, 23)
        Me.radWisconsin.TabIndex = 4
        Me.radWisconsin.Text = "&Wisconsin"
        '
        'radLittleRock
        '
        Me.radLittleRock.Location = New System.Drawing.Point(9, 52)
        Me.radLittleRock.Margin = New System.Windows.Forms.Padding(2)
        Me.radLittleRock.Name = "radLittleRock"
        Me.radLittleRock.Size = New System.Drawing.Size(100, 23)
        Me.radLittleRock.TabIndex = 1
        Me.radLittleRock.Text = "&Little Rock"
        '
        'radMadison
        '
        Me.radMadison.Location = New System.Drawing.Point(9, 79)
        Me.radMadison.Margin = New System.Windows.Forms.Padding(2)
        Me.radMadison.Name = "radMadison"
        Me.radMadison.Size = New System.Drawing.Size(100, 23)
        Me.radMadison.TabIndex = 2
        Me.radMadison.Text = "&Madison"
        '
        'radFrankfort
        '
        Me.radFrankfort.Checked = True
        Me.radFrankfort.Location = New System.Drawing.Point(9, 25)
        Me.radFrankfort.Margin = New System.Windows.Forms.Padding(2)
        Me.radFrankfort.Name = "radFrankfort"
        Me.radFrankfort.Size = New System.Drawing.Size(100, 23)
        Me.radFrankfort.TabIndex = 0
        Me.radFrankfort.TabStop = True
        Me.radFrankfort.Text = "&Frankfort"
        '
        'radSpringfield
        '
        Me.radSpringfield.Location = New System.Drawing.Point(9, 134)
        Me.radSpringfield.Margin = New System.Windows.Forms.Padding(2)
        Me.radSpringfield.Name = "radSpringfield"
        Me.radSpringfield.Size = New System.Drawing.Size(100, 23)
        Me.radSpringfield.TabIndex = 4
        Me.radSpringfield.Text = "Springfiel&d"
        '
        'radSalem
        '
        Me.radSalem.Location = New System.Drawing.Point(9, 107)
        Me.radSalem.Margin = New System.Windows.Forms.Padding(2)
        Me.radSalem.Name = "radSalem"
        Me.radSalem.Size = New System.Drawing.Size(100, 23)
        Me.radSalem.TabIndex = 3
        Me.radSalem.Text = "&Salem"
        '
        'btnVerify
        '
        Me.btnVerify.Location = New System.Drawing.Point(47, 257)
        Me.btnVerify.Margin = New System.Windows.Forms.Padding(2)
        Me.btnVerify.Name = "btnVerify"
        Me.btnVerify.Size = New System.Drawing.Size(131, 35)
        Me.btnVerify.TabIndex = 0
        Me.btnVerify.Text = "&Verify Answer"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(182, 257)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(131, 35)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "E&xit"
        '
        'lblMsg
        '
        Me.lblMsg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMsg.Location = New System.Drawing.Point(30, 212)
        Me.lblMsg.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblMsg.Name = "lblMsg"
        Me.lblMsg.Size = New System.Drawing.Size(294, 31)
        Me.lblMsg.TabIndex = 4
        Me.lblMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radArkansas)
        Me.GroupBox1.Controls.Add(Me.radIllinois)
        Me.GroupBox1.Controls.Add(Me.radOregon)
        Me.GroupBox1.Controls.Add(Me.radKentucky)
        Me.GroupBox1.Controls.Add(Me.radWisconsin)
        Me.GroupBox1.Location = New System.Drawing.Point(30, 16)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(120, 170)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "State"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.radMadison)
        Me.GroupBox2.Controls.Add(Me.radLittleRock)
        Me.GroupBox2.Controls.Add(Me.radFrankfort)
        Me.GroupBox2.Controls.Add(Me.radSpringfield)
        Me.GroupBox2.Controls.Add(Me.radSalem)
        Me.GroupBox2.Location = New System.Drawing.Point(204, 16)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(120, 170)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "City"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(361, 316)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblMsg)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnVerify)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "States and Capitals"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents radArkansas As System.Windows.Forms.RadioButton
    Friend WithEvents radIllinois As System.Windows.Forms.RadioButton
    Friend WithEvents radOregon As System.Windows.Forms.RadioButton
    Friend WithEvents radKentucky As System.Windows.Forms.RadioButton
    Friend WithEvents radWisconsin As System.Windows.Forms.RadioButton
    Friend WithEvents radLittleRock As System.Windows.Forms.RadioButton
    Friend WithEvents radMadison As System.Windows.Forms.RadioButton
    Friend WithEvents radFrankfort As System.Windows.Forms.RadioButton
    Friend WithEvents radSpringfield As System.Windows.Forms.RadioButton
    Friend WithEvents radSalem As System.Windows.Forms.RadioButton
    Friend WithEvents btnVerify As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblMsg As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox

End Class
