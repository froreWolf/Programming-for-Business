﻿' Name:         Division Project
' Purpose:      Displays the quotient after dividing
'               the larger number by the smaller number
' Programmer:  <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub ClearLabel(sender As Object, e As EventArgs) Handles txtNum1.TextChanged, txtNum2.TextChanged
        lblQuotient.Text = String.Empty
    End Sub

End Class
